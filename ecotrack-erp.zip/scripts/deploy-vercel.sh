#!/bin/bash
# ─── EcoTrack ERP - Vercel Deploy Script ───────────────────
# This script helps you deploy to Vercel step by step.
# Run: bash scripts/deploy-vercel.sh

set -e

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║   🌿 EcoTrack ERP - Vercel Deployment Helper    ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# ── Step 1: Check prerequisites ─────────────────────────────
echo "📋 Step 1: Checking prerequisites..."
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Install from https://nodejs.org"
    exit 1
fi
echo "   ✅ Node.js $(node -v)"

# Check Git
if ! command -v git &> /dev/null; then
    echo "❌ Git not found. Install Git first."
    exit 1
fi
echo "   ✅ Git $(git --version | head -1)"

# Check Vercel CLI
if ! command -v vercel &> /dev/null; then
    echo "   ⚠️  Vercel CLI not found. Installing..."
    npm install -g vercel
fi
echo "   ✅ Vercel CLI installed"

# Check if logged in to Vercel
if ! vercel whoami &> /dev/null; then
    echo ""
    echo "   Please log in to Vercel:"
    vercel login
fi
VERCEL_USER=$(vercel whoami 2>/dev/null)
echo "   ✅ Logged in as: $VERCEL_USER"

# ── Step 2: Get Database URL ────────────────────────────────
echo ""
echo "📋 Step 2: Database Configuration"
echo ""
echo "   You need a PostgreSQL database. Free options:"
echo "   • Neon    → https://neon.tech  (recommended)"
echo "   • Supabase → https://supabase.com"
echo ""

if [ -f .env ]; then
    source .env 2>/dev/null || true
fi

if [ -n "$DATABASE_URL" ]; then
    echo "   Found DATABASE_URL in .env:"
    # Mask the password
    MASKED=$(echo "$DATABASE_URL" | sed 's/:\/\/[^:]*:[^@]*@/:\/\/***:***@/')
    echo "   $MASKED"
    echo ""
    read -p "   Use this URL? (Y/n): " USE_EXISTING
    if [[ "$USE_EXISTING" =~ ^[Nn] ]]; then
        read -p "   Enter your DATABASE_URL: " DATABASE_URL
    fi
else
    echo "   No DATABASE_URL found in .env"
    echo ""
    read -p "   Enter your DATABASE_URL: " DATABASE_URL
fi

if [ -z "$DATABASE_URL" ]; then
    echo "❌ DATABASE_URL is required. Exiting."
    exit 1
fi

# ── Step 3: Push Database Schema ────────────────────────────
echo ""
echo "📋 Step 3: Applying database schema..."
DATABASE_URL="$DATABASE_URL" npx drizzle-kit push
echo "   ✅ Database schema applied"

# ── Step 4: Initialize Git ──────────────────────────────────
echo ""
echo "📋 Step 4: Preparing Git repository..."

if [ ! -d .git ]; then
    git init
    echo "   ✅ Initialized git repo"
fi

# Create .gitignore if needed
if [ ! -f .gitignore ]; then
    echo "   ⚠️  No .gitignore found"
fi

git add -A
git status --short
echo ""
read -p "   Commit all files? (Y/n): " DO_COMMIT
if [[ ! "$DO_COMMIT" =~ ^[Nn] ]]; then
    git commit -m "🌿 EcoTrack ERP - Waste Management System" 2>/dev/null || echo "   (nothing new to commit)"
fi

# ── Step 5: Deploy to Vercel ────────────────────────────────
echo ""
echo "📋 Step 5: Deploying to Vercel..."
echo ""
echo "   The Vercel CLI will ask you a few questions."
echo "   For most prompts, the defaults are fine."
echo ""
read -p "   Press Enter to start deployment..."

vercel --env DATABASE_URL="$DATABASE_URL"

# ── Step 6: Get the URL ─────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║   🎉 Deployment Complete!                       ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "   Your app is now live on Vercel!"
echo ""
echo "   📌 Next steps:"
echo "   1. Open your Vercel dashboard: https://vercel.com/dashboard"
echo "   2. Find your project and click the deployment URL"
echo "   3. Click 'Load Demo Data' on the dashboard"
echo ""
echo "   Or seed via API:"
echo "   curl -X POST https://YOUR-APP.vercel.app/api/seed"
echo ""
echo "   📌 To set the DATABASE_URL permanently in Vercel:"
echo "   vercel env add DATABASE_URL production"
echo ""
